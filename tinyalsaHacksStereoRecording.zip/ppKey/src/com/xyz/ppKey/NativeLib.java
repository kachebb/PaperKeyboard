package com.xyz.ppKey;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import android.app.Activity;
import android.util.Log;
import android.widget.TextView;
import android.os.Bundle;
import android.os.SystemClock;


public class NativeLib extends Activity {
	private static final String LTAG = "myTag";
	//private Thread recordingThread = null;
    private Thread recordingThread = new Thread(new Runnable() {
        
        @Override
        public void run() {
        	//stringFromJNI();
        	
        	try {
            	Process p = null;
            	p = Runtime.getRuntime().exec("/system/xbin/su");
            	DataOutputStream os = new DataOutputStream(p.getOutputStream());
            	Log.d(LTAG, "Starts!");
    			SystemClock.sleep(100);
    			
    			os.writeBytes("/system/bin/tinymix 27 120\n");
    			os.flush();
    			SystemClock.sleep(100);
    			os.writeBytes("/system/bin/tinymix 54 11\n");
    			os.flush();
    			SystemClock.sleep(100);
    			os.writeBytes("/system/bin/tinymix 55 12\n");
    			os.flush();
    			SystemClock.sleep(100);
    			os.writeBytes("/system/bin/tinymix 76 1\n");
    			os.flush();
    			SystemClock.sleep(100);
    			os.writeBytes("/system/bin/tinymix 77 1\n");
    			os.flush();
    			SystemClock.sleep(100);
    			
    			os.writeBytes("/system/xbin/killall tinycap\n");
				os.flush();
				SystemClock.sleep(500);
				Log.d(LTAG, "killing existing tinycap process before recording!");
    			
    			
    			BufferedInputStream reader = new BufferedInputStream(
    					p.getInputStream());
    			byte[] buffer = new byte[1024];
    			int read;
    			
    			// Clear existing stdout buffer
    			try {
        				while (reader.available() > 0) {
        					read = reader.read(buffer);
        					Log.d(LTAG, "Trying to clear stdout buffer");
        					Log.d(LTAG, new String(buffer));
        				}
        		} catch (IOException e) {
        			e.printStackTrace();
        		}
    			
    			Log.d(LTAG, "Start tinycap!");
    			
            	os.writeBytes("/system/bin/tinycap /sdcard/tmp.wav -D 0 -d 1 -c 2 -r 48000 -b 16\n");
            	os.flush();
            	
    			BufferedOutputStream outputF = new BufferedOutputStream(
    					new FileOutputStream("/sdcard/rawfile.pcm"));
    			int ct = 0;
    			try {
    			while ((read = reader.read(buffer)) > 0) {
    				ct += read;
    				//Log.d(LTAG, "Read data: " + new String(buffer));
    				outputF.write(buffer, 0, read);
    				// xyz: buffer stores audio signals that should be processed 
    				if (ct > 2000) { //xyz: an example of how to terminate
    					os.writeBytes("/system/xbin/killall tinycap\n");
    					os.flush();
    					Log.d(LTAG, "tinycap killed after recording!");
    					break;
    				}
    			}
    			outputF.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    			Log.d(LTAG, "Done recording!");
            } catch (Exception e) {
    			e.printStackTrace();
    			System.exit(0);
    		}
        }
    },"AudioRecorder Thread");
    
    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first

        // Release tinycap
        try {
        Process p = null;
    	p = Runtime.getRuntime().exec("/system/xbin/su");
    	DataOutputStream os = new DataOutputStream(p.getOutputStream());
    	os.writeBytes("/system/xbin/killall tinycap\n");
		os.flush();
		Log.d(LTAG, "tinycap killed in onPause!");
        } catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
    }
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /* Create a TextView and set its content.
         * the text is retrieved by calling a native
         * function.
         */
        TextView  tv = new TextView(this);
        recordingThread.start();
        //tv.setText(stringFromJNI());
        tv.setText("Hello1!");
        try {
        	//Process p = null;
        	//p = Runtime.getRuntime().exec("/system/xbin/su");
        	//DataOutputStream os = new DataOutputStream(p.getOutputStream());
        	
        	/*os.writeBytes("/system/xbin/alsa_amixer set 'AMIC UL' 120\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/xbin/alsa_amixer set 'MUX_UL11' 'AMic0'\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/xbin/alsa_amixer set 'MUX_UL10' 'AMic1'\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/xbin/alsa_amixer set 'Analog Left' 'Main Mic'\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/xbin/alsa_amixer set 'Analog Right' 'Sub Mic'\n");
			os.flush();
			SystemClock.sleep(1000);
			
			os.writeBytes("/system/xbin/alsa_aplay -C -D hw:0,1 -c 2 -r 48000 -d 5 -f S16_LE /sdcard/alsaF.wav\n");
			os.flush();
			*/
			
			/* //os.writeBytes("/system/bin/tinymix 4 0\n");
			//os.flush();
			//SystemClock.sleep(1000);
			os.writeBytes("/system/bin/tinymix 27 118\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/bin/tinymix 54 11\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/bin/tinymix 55 12\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/bin/tinymix 76 1\n");
			os.flush();
			SystemClock.sleep(1000);
			os.writeBytes("/system/bin/tinymix 77 1\n");
			os.flush();
			SystemClock.sleep(1000);
			
			//os.writeBytes("/system/xbin/alsa_aplay -C -D hw:0,1 -c 2 -r 48000 -d 5 -f S16_LE /sdcard/alsaF.wav\n");
			//os.flush();
			*/
        	
			//os.writeBytes("/system/xbin/tinycap /sdcard/file2.wav -D 0 -d 1 -c 2 -r 48000 -b 16 -p 8 -n 8\n");
        	//os.writeBytes("/system/xbin/tinycap /sdcard/file2.wav -D 0 -d 1 -c 2\n");
			//os.flush();
			//SystemClock.sleep(1000);
			
        	/*os.writeBytes("/system/bin/tinycap\n");
        	os.flush();
			char[] buffer = new char[5];
			String output = "";
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			int read;
			if ((read = reader.read(buffer)) > 0) {
				output = new String(buffer);
			}
			Log.d(this.toString(), "cmd output: " + output);
			SystemClock.sleep(1000);
			*/
        }
        catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
        
        //tv.setText( stringFromJNI() );
        setContentView(tv);
    }
    


    /* A native method that is implemented by the
     * 'hello-jni' native library, which is packaged
     * with this application.
     */
    public native String  stringFromJNI();

    /* This is another native method declaration that is *not*
     * implemented by 'hello-jni'. This is simply to show that
     * you can declare as many native methods in your Java code
     * as you want, their implementation is searched in the
     * currently loaded native libraries only the first time
     * you call them.
     *
     * Trying to call this function will result in a
     * java.lang.UnsatisfiedLinkError exception !
     */
    public native String  unimplementedStringFromJNI();

    /* this is used to load the 'hello-jni' library on application
     * startup. The library has already been unpacked into
     * /data/data/com.example.hellojni/lib/libhello-jni.so at
     * installation time by the package manager.
     */
    static {
    	try{
    		//System.loadLibrary("tinyalsa");
    		//System.loadLibrary("foo");
    		System.loadLibrary("hello-jni");
    	}
    	catch (UnsatisfiedLinkError e) {
    	       Log.e("Error..1", e.toString());
    	}
    }
    

    
}