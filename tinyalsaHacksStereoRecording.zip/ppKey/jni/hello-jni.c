#include <string.h>
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <signal.h>
#include <android/log.h>

#include <include/tinyalsa/asoundlib.h>

#define  LOG_TAG    "NativeLib"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
#define  LOGV(...)  __android_log_print(ANDROID_LOG_VERBOSE,LOG_TAG,__VA_ARGS__)

jstring
Java_com_xyz_ppKey_NativeLib_stringFromJNI( JNIEnv* env,
                                                  jobject thiz )
{

		struct pcm_config config;
	    struct pcm *pcm;

	    char *buffer;
	    unsigned int size;
	    unsigned int bytes_read = 0;
	    unsigned int card = 0;
	    unsigned int device = 1;
	    unsigned int idx;


	    /*//fprintf(stderr, "Test stderr redirect\n");
	    system("su -c /system/bin/tinymix 76 1");

	    int pipes[2];
	    pipe(pipes);
	    dup2(pipes[1], fileno(stderr));
	    FILE *inputFile = fdopen(pipes[0], "r");
	    char readBuffer[256];
	    while (1) {

	    	__android_log_print(ANDROID_LOG_INFO, "Native", "TEST LOG loop");
	        fgets(readBuffer, sizeof(readBuffer), inputFile);

	        //__android_log_write(2, "stderr", readBuffer);
	        //LOGV(readBuffer);
	        __android_log_write(ANDROID_LOG_INFO, "LOOP", readBuffer);
	    }
	    */
	    struct mixer *mixer;
	    struct mixer_ctl *ctl;

	    FILE *file = fopen("/sdcard/test.wav", "wb");
	    if (!file) {
	        fprintf(stderr, "Unable to create wav file\n");
	        return (*env)->NewStringUTF(env, "Unable to create wav file\n");
	    }


	    mixer = mixer_open(0);
	    if (!mixer) {
	        fprintf(stderr, "Failed to open mixer\n");
	        return (*env)->NewStringUTF(env, "Failed to open mixer\n");
	    }

	    /*
	    //ctl = mixer_get_ctl(mixer, 4);
	    //if (mixer_ctl_set_value(ctl, 0, 0))
	    //	return (*env)->NewStringUTF(env, "Invalid value for 4");
	    //mixer_close(mixer);

	    mixer = mixer_open(card);
        ctl = mixer_get_ctl(mixer, 27);
	    if (mixer_ctl_set_value(ctl, 0, 118))
	    	return (*env)->NewStringUTF(env, "Invalid value for 27");
	    mixer_close(mixer);
	    mixer = mixer_open(card);
        ctl = mixer_get_ctl(mixer, 54);
	    if (mixer_ctl_set_value(ctl, 0, 11))
	    	return (*env)->NewStringUTF(env, "Invalid value for 54");
	    mixer_close(mixer);
	    mixer = mixer_open(card);
        ctl = mixer_get_ctl(mixer, 55);
	    if (mixer_ctl_set_value(ctl, 0, 12))
	    	return (*env)->NewStringUTF(env, "Invalid value for 55");
	    mixer_close(mixer);
	    mixer = mixer_open(card);
        ctl = mixer_get_ctl(mixer, 76);
	    if (mixer_ctl_set_value(ctl, 0, 1))
	    	return (*env)->NewStringUTF(env, "Invalid value for 76"); 
	    mixer_close(mixer);
	    mixer = mixer_open(card);
        ctl = mixer_get_ctl(mixer, 77);
	    if (mixer_ctl_set_value(ctl, 0, 1))
	    	return (*env)->NewStringUTF(env, "Invalid value for 77"); 

	    mixer_close(mixer);
		*/

	    /*
	     	struct wav_header header;
	     	header.riff_id = ID_RIFF;
	        header.riff_sz = 0;
	        header.riff_fmt = ID_WAVE;
	        header.fmt_id = ID_FMT;
	        header.fmt_sz = 16;
	        header.audio_format = FORMAT_PCM;
	        header.num_channels = channels;
	        header.sample_rate = rate;
	        header.bits_per_sample = bits;
	        header.byte_rate = (header.bits_per_sample / 8) * channels * rate;
	        header.block_align = channels * (header.bits_per_sample / 8);
	        header.data_id = ID_DATA;

	        // leave enough room for header
	        fseek(file, sizeof(struct wav_header), SEEK_SET);
	        */
	    config.channels = 2;
	    config.rate = 48000;
	    config.period_size = 8;
	    config.period_count = 8;
	    config.format = PCM_FORMAT_S16_LE;
	    config.start_threshold = 0;
	    config.stop_threshold = 0;
	    config.silence_threshold = 0;

	    pcm = pcm_open(card, 1, PCM_IN, &config);
	    if (!pcm || !pcm_is_ready(pcm)) {
	        fprintf(stderr, "Unable to open PCM device (%s)\n",
	                pcm_get_error(pcm));
	        return (*env)->NewStringUTF(env, "Unable to open PCM device\n");
	    }

	    size = pcm_frames_to_bytes(pcm, pcm_get_buffer_size(pcm));
	    buffer = malloc(size);
	    if (!buffer) {
	        fprintf(stderr, "Unable to allocate %d bytes\n", size);
	        free(buffer);
	        pcm_close(pcm);
	        return (*env)->NewStringUTF(env, "Unable to allocate bytes");
	    }

	    printf("Capturing sample: %u ch, %u hz\n", config.channels,
	    		config.rate);//, pcm_format_to_bits(config.format));

	    int err = 0;
	    while (bytes_read < 1000 && !pcm_read(pcm, buffer, size)) {
	        if (fwrite(buffer, 1, size, file) != size) {
	            fprintf(stderr,"Error capturing sample\n");
	            err = 1;
	            break;
	        }
	        bytes_read += size;
	    }

	    free(buffer);
	    pcm_close(pcm);
	    if (err)
	    	return (*env)->NewStringUTF(env, "Error capturing sample");

	char str[15];
	sprintf(str, "Bytes: %d", bytes_read);
    return (*env)->NewStringUTF(env, str);
}
